


$(function () {
    const globeContainer = $('#globe-container');
    const width = globeContainer.width();
    const height = globeContainer.height();

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    camera.position.z = 5;

    const renderer = new THREE.WebGLRenderer();
    renderer.setSize(width, height);
    globeContainer.append(renderer.domElement);

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.minDistance = 3;
    controls.maxDistance = 10;

    const geometry = new THREE.SphereGeometry(2, 32, 32);
    const texture = new THREE.TextureLoader().load('https://cdn.jsdelivr.net/gh/mrdoob/three.js@r128/examples/textures/land_ocean_ice_cloud_2048.jpg');
    const material = new THREE.MeshBasicMaterial({ map: texture });
    const globe = new THREE.Mesh(geometry, material);
    scene.add(globe);

    const satelliteGeometry = new THREE.SphereGeometry(0.1, 16, 16);
    const satelliteMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
    const satellite = new THREE.Mesh(satelliteGeometry, satelliteMaterial);
    satellite.position.set(0, 0, -2.5);
    camera.add(satellite);
    scene.add(camera);
    let prevCameraPosition = new THREE.Vector3().copy(camera.position);

    async function getPopulationAt(latitude, longitude) {
        const apiUrl = `http://api.geonames.org/findNearbyPlaceNameJSON?lat=${latitude}&lng=${longitude}&username=lab4892coe`;

        try {
            const response = await fetch(apiUrl);
            const data = await response.json();

            if (data.geonames && data.geonames.length > 0) {
                const population = data.geonames[0].population;
                console.log('API Response:', data);
                console.log('Population:', population);

                if (population === 0) {
                    return 'Population data not available';
                }

                return population;
            }
        } catch (error) {
            console.error('Error fetching population:', error);
        }

        return 'Population data not available';
    }

    function updateGlobeData() {
    const vector = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
    const latitude = (Math.asin(vector.y) / Math.PI) * 180;
    const longitude = (Math.atan2(vector.x, vector.z) / Math.PI) * 180;

    if (!camera.position.equals(prevCameraPosition)) {
        prevCameraPosition.copy(camera.position);

        // Update population
        getPopulationAt(latitude, longitude).then((population) => {
            $('#population').text(population.toLocaleString());
        });

        // Update peak usage time
        const currentTime = parseInt($('#time-input').val());
        const peakUsage = getPeakUsage(currentTime);
        updatePeakUsageDisplay(peakUsage);
    }
}

function fetchPopulationAndSatelliteImage() {
    updateGlobeData();
    updateSatelliteImage();
}

$('#fetch-population').on('click', function () {
    fetchPopulationAndSatelliteImage();
});


    async function getSatelliteImage(latitude, longitude) {
    const apiKey = 'AIzaSyCL_shNyeurNkFVpHglzvJDz1QwPdkb7_0';
    const imgUrl = `https://maps.googleapis.com/maps/api/staticmap?center=${latitude},${longitude}&zoom=13&size=300x200&maptype=satellite&key=${apiKey}`;

    try {
        const response = await fetch(imgUrl);

        if (response.ok) {
            return imgUrl;
        }
    } catch (error) {
        console.error('Error fetching satellite image:', error);
    }

    return 'path/to/your/placeholder-image.jpg';
}

    function updateSatelliteImage() {
    const vector = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
    const latitude = (Math.asin(vector.y) / Math.PI) * 180;
    const longitude = (Math.atan2(vector.x, vector.z) / Math.PI) * 180;

    if (!camera.position.equals(prevCameraPosition)) {
        prevCameraPosition.copy(camera.position);
        getSatelliteImage(latitude, longitude).then((imgUrl) => {
            $('#satellite-image').attr('src', imgUrl);
        });
    }
}

    function fetchPopulationData() {
        updatePopulation();
        updateSatelliteImage();
    }

    $('#fetch-population').on('click', function () {
        fetchPopulationData();
    });
    $('#fetch-satellite-image').on('click', function () {
    updateSatelliteImage();
    });


    //peak usage

    // Sample satellite usage data
    const usageData = [
    { time: 0, usage: 1000 },
    { time: 1, usage: 1500 },
    { time: 2, usage: 2000 },
    { time: 3, usage: 250 },
    { time: 4, usage: 2000 },
    { time: 5, usage: 15000 },
    { time: 6, usage: 3000 },
    { time: 7, usage: 3554 },
    { time: 8, usage: 4045 },
    { time: 9, usage: 3545 },
    { time: 10, usage: 30453 },
    { time: 11, usage: 25435 },
    { time: 12, usage: 20213 },
    { time: 13, usage: 15123 },
    { time: 14, usage: 132130 },
    { time: 15, usage: 3155 },
    { time: 16, usage: 15350 },
    { time: 17, usage: 18465 },
    { time: 18, usage: 24560 },
    { time: 19, usage: 28465 },
    { time: 20, usage: 35410 },
    { time: 21, usage: 34835 },
    { time: 22, usage: 40158 },
    { time: 23, usage: 444865 },
];

    function getPeakUsage(time) {
    const usage = usageData.find((item) => item.time === time);
    return usage ? usage.usage : '-';
}
    function updatePeakUsageDisplay(usage) {
    $('#peak-usage').text(usage);
    }

    $('#time-input, #time-slider').on('input', function () {
    const time = parseInt($(this).val());
    const peakUsage = getPeakUsage(time);
    updatePeakUsageDisplay(peakUsage);
    });


    function animate() {
        requestAnimationFrame(animate);
        renderer.render(scene, camera);
        controls.update();
    }

    animate();
});


